export const ROLER = {
  // 管理员
  admin: 'admin',
  // 项目管理员
  teacher: 'teacher',
  // 普通员工
  consumer: 'consumer'
}
